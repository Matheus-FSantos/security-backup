package io.github.MatheusFSantos.ClientMS;

import io.github.MatheusFSantos.ClientMS.model.domain.Client;
import io.github.MatheusFSantos.ClientMS.model.exception.ClientMSException;
import io.github.MatheusFSantos.ClientMS.model.service.ClientService;
import io.github.MatheusFSantos.ClientMS.model.validation.ClientValidation;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Arrays;
import java.util.List;

@SpringBootTest
class ClientMsApplicationTests {

	private Client clientValid;

	private Client clientInvalid;

	@Autowired
	private ClientService clientService;

	@BeforeEach
	private void setUp() {
		this.clientValid = new Client("11123198763", "Matheus Ferreira Santos", "matheus.fs.contato@gmail.com", 19);
		this.clientInvalid = new Client("111231987632", "Matheus Ferreira Santos", "matheus.fs.contato@gmail.com", 25);
	}

	@Test
	void clientMsServiceVerify() {
		List<Client> clientList = Arrays.asList(this.clientValid, this.clientInvalid);

		clientList.forEach(client -> {
			try {
				this.clientService.save(client);
				System.out.println("The client " + client.getName() + " was successfully saved!");
			} catch(ClientMSException clientMSException) {
				System.out.println(clientMSException.getExceptionMessages());
			}
		});
	}

}
