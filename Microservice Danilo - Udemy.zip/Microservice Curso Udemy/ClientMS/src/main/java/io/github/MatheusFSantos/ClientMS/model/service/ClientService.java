package io.github.MatheusFSantos.ClientMS.model.service;

import io.github.MatheusFSantos.ClientMS.model.domain.Client;
import io.github.MatheusFSantos.ClientMS.model.exception.ClientMSException;
import io.github.MatheusFSantos.ClientMS.model.validation.ClientValidation;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import io.github.MatheusFSantos.ClientMS.model.repository.ClientRepository;

import javax.transaction.Transactional;
import java.util.List;

@Service
public class ClientService {

    @Autowired
    private ClientRepository clientRepository;

    public List<Client> findAll() {
        return this.clientRepository.findAll();
    }

    public Client findByCPF(String cpf) {
        return this.clientRepository.findById(cpf).orElse(null);
    }

    @Transactional
    public void save(Client client) throws ClientMSException {

        ClientValidation.validation(client);

        if(this.findByCPF(client.getCPF()) != null)
            throw new ClientMSException("Client already exists!");
        if(this.clientRepository.findByEmail(client.getEmail()).isPresent())
            throw new ClientMSException("Client already exists!");

        client.updateCreatedAt();
        client.updateUpdatedAt();

        this.clientRepository.save(client);
    }

    @Transactional
    public void update(String cpf, Client updatedClient) throws ClientMSException {
        updatedClient.updateCPF(cpf);
        ClientValidation.validation(updatedClient);


        Client olderClient = this.findByCPF(cpf);

        if(olderClient == null)
            throw new ClientMSException("Client not found!");

        if(!updatedClient.getEmail().equals(olderClient.getEmail()))
            if(this.clientRepository.findByEmail(updatedClient.getEmail()).isPresent())
                throw new ClientMSException("Client already exists!");

        updatedClient.updateCreatedAt(olderClient.getCreatedAt());
        updatedClient.updateUpdatedAt();

        this.clientRepository.save(updatedClient);
    }

    @Transactional
    public void delete(String cpf) throws ClientMSException {
        if(this.findByCPF(cpf) == null)
            throw new ClientMSException("Client not found!");

        this.clientRepository.deleteById(cpf);
    }

}
