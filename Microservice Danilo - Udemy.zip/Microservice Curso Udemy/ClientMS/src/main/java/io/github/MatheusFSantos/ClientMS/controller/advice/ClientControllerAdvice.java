package io.github.MatheusFSantos.ClientMS.controller.advice;

import io.github.MatheusFSantos.ClientMS.model.DTO.ClientMSExceptionDTO;
import io.github.MatheusFSantos.ClientMS.model.exception.ClientMSException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ClientControllerAdvice {

    @ExceptionHandler(ClientMSException.class)
    public ResponseEntity<?> handleClientMSExceptions(ClientMSException clientMSException) {
        return ResponseEntity.badRequest().body(
                new ClientMSExceptionDTO(clientMSException.getExceptionMessages(), clientMSException.getExceptionClass(), clientMSException.getExceptionDate())
        );
    }

}
