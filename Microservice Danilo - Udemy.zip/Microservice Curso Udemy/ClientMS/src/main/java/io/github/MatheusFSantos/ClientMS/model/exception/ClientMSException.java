package io.github.MatheusFSantos.ClientMS.model.exception;

import org.springframework.stereotype.Component;

import java.util.*;
import java.io.Serializable;
import java.time.LocalDateTime;

@Component
public class ClientMSException extends Exception implements Serializable {

    private static final long serialVersionUID = 1L;

    private final List<String> exceptionMessages;
    private final String exceptionClass;
    private final LocalDateTime exceptionDate;

    public ClientMSException() {
        this.exceptionMessages = new ArrayList<>();
        this.exceptionClass = "Client.class";
        this.exceptionDate = LocalDateTime.now();
    }

    public ClientMSException(String exceptionMessages) {
        this.exceptionMessages = Collections.singletonList(exceptionMessages);
        this.exceptionClass = "Client.class";
        this.exceptionDate = LocalDateTime.now();
    }

    public ClientMSException(List<String> exceptionMessages) {
        this.exceptionMessages = exceptionMessages;
        this.exceptionClass = "Client.class";
        this.exceptionDate = LocalDateTime.now();
    }

    public List<String> getExceptionMessages() {
        return exceptionMessages;
    }

    public String getExceptionClass() {
        return exceptionClass;
    }

    public LocalDateTime getExceptionDate() {
        return exceptionDate;
    }

}
