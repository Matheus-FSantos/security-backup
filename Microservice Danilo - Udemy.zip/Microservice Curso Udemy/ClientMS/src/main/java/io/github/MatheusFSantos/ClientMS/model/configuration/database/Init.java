package io.github.MatheusFSantos.ClientMS.model.configuration.database;

import io.github.MatheusFSantos.ClientMS.model.domain.Client;
import io.github.MatheusFSantos.ClientMS.model.repository.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class Init {

    @Bean
    public CommandLineRunner initValues(
            @Autowired ClientRepository clientRepository
    ) {
        return args -> {
            Client c1 = new Client("111231987632", "Matheus Ferreira Santos", "matheus.fs.contato@gmail.com", 19);
            Client c2 = new Client("542098317621", "Usuário teste", "teste@gmail.com", 20);
            Client c3 = new Client("542098314432", "Usuário teste 2", "teste2@gmail.com", 54);
            clientRepository.save(c1);
            clientRepository.save(c2);
            clientRepository.save(c3);
        };
    }
}
