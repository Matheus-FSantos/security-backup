package io.github.MatheusFSantos.ClientMS.model.validation;

import io.github.MatheusFSantos.ClientMS.model.domain.Client;
import io.github.MatheusFSantos.ClientMS.model.exception.ClientMSException;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ClientValidation {

    public static void validation(Client client) throws ClientMSException {
        List<String> messages = new ArrayList<>();

        ClientValidation.validationCPF(messages, client.getCPF());

        ClientValidation.validationName(messages, client.getName());

        ClientValidation.validationEmail(messages, client.getEmail());

        if(!messages.isEmpty())
            throw new ClientMSException(messages);
    }

    private static void validationCPF(List<String> messages, String CPF) {
        if(CPF == null)
            messages.add("CPF is required!");
        else if(CPF.length() != 11)
            messages.add("Invalid fields!");
        else if(CPF.contains(".") || CPF.contains("-"))
            messages.add("Invalid fields!");
    }

    private static void validationName(List<String> messages, String name) {
        if(name == null)
            messages.add("Name is required!");
        else if(name.length() < 4 || name.length() > 60)
            if(!messages.contains("Invalid fields!"))
                messages.add("Invalid fields!");
    }

    private static void validationEmail(List<String> messages, String email) {
        if(email == null){
            messages.add("E-mail is required!");
            return;
        }

        String regex = "^[\\w!#$%&amp;'*+/=?`{|}~^-]+(?:\\.[\\w!#$%&amp;'*+/=?`{|}~^-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,6}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(email);


        if(email.length() < 4 || email.length() > 120) {
            if(!messages.contains("Invalid fields!"))
                messages.add("Invalid fields!");
        } else if(!matcher.matches())
            if(!messages.contains("Invalid fields!"))
                messages.add("Invalid fields!");
    }
}
