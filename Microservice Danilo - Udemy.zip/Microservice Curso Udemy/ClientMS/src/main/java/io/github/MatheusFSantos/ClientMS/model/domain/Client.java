package io.github.MatheusFSantos.ClientMS.model.domain;

import com.fasterxml.jackson.annotation.JsonFormat;

import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;

@Entity
@Component
@Table(name = "client_tb")
public class Client implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(nullable = false, unique = true)
    private String CPF;

    @Column(nullable = false, length = 60)
    private String name;

    @Column(nullable = false, unique = true, length = 120)
    private String email;

    @Column(nullable = false)
    private Integer age;

    @JsonFormat(pattern = "dd/MM/yyyy HH:mm:s")
    @Column(nullable = false)
    private LocalDateTime createdAt;

    @JsonFormat(pattern = "dd/MM/yyyy HH:mm:s")
    @Column(nullable = false)
    private LocalDateTime updatedAt;

    public Client() { }

    public Client(String CPF, String name, String email, Integer age) {
        this.CPF = CPF;
        this.name = name;
        this.email = email;
        this.age = age;
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    public String getCPF() {
        return CPF;
    }

    public void updateCPF(String CPF) {
        this.setCPF(CPF);
    }

    private void setCPF(String CPF) {
        this.CPF = CPF;
    }

    public String getName() {
        return name;
    }

    public void updateName(String name) {
        this.setName(name);
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void updateEmail(String email) {
        this.setEmail(email);
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getAge() {
        return age;
    }

    public void updateAge(Integer age) {
        this.setAge(age);
    }

    private void setAge(Integer age) {
        this.age = age;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void updateCreatedAt() {
        this.setCreatedAt(LocalDateTime.now());
    }

    public void updateCreatedAt(LocalDateTime createdAt) {
        this.setCreatedAt(createdAt);
    }

    private void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void updateUpdatedAt() {
        this.setUpdatedAt(LocalDateTime.now());
    }

    private void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    /* FORMATTED FIELDS */
    public String getFormattedCPF() {
        String formattedCPF = "";

        for(int i = 0; i < this.getCPF().length(); i++){
            if(i == 2 || i == 5)
                formattedCPF = formattedCPF.concat(this.getCPF().substring(i, i + 1).concat("."));
            else if(i == 8)
                formattedCPF = formattedCPF.concat(this.getCPF().substring(i, i + 1).concat("-"));
            else
                formattedCPF = formattedCPF.concat(this.getCPF().substring(i, i + 1));
        }

        return formattedCPF;
    }

}
