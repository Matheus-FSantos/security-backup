package io.github.MatheusFSantos.ClientMS.controller;

import io.github.MatheusFSantos.ClientMS.model.exception.ClientMSException;
import io.github.MatheusFSantos.ClientMS.model.service.ClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import io.github.MatheusFSantos.ClientMS.model.domain.Client;

import java.util.List;

@RestController
@RequestMapping(value = "/api/clients")
public class ClientController {

    @Autowired
    private ClientService clientService;

    @GetMapping
    public ResponseEntity<List<Client>> findAll() {
        List<Client> clientList = this.clientService.findAll();

        if(!clientList.isEmpty())
            return ResponseEntity.ok().body(clientList);

        return ResponseEntity.notFound().build();
    }

    @GetMapping(params = "cpf")
    public ResponseEntity<Client> findByCPF(@RequestParam String cpf) {
        Client client = this.clientService.findByCPF(cpf);

        if(client != null)
            return ResponseEntity.ok().body(client);

        return ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<Void> save(@RequestBody Client client) throws ClientMSException {
        this.clientService.save(client);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @PutMapping(params = "cpf")
    public ResponseEntity<Void> update(@RequestParam String cpf, @RequestBody Client client) throws ClientMSException {
        this.clientService.update(cpf, client);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping(params = "cpf")
    public ResponseEntity<Void> delete(@RequestParam String cpf) throws ClientMSException {
        this.clientService.delete(cpf);
        return ResponseEntity.noContent().build();
    }

}
