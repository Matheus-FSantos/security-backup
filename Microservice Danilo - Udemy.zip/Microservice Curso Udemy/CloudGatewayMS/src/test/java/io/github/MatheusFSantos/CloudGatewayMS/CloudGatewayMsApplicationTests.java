package io.github.MatheusFSantos.CloudGatewayMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudGatewayMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
