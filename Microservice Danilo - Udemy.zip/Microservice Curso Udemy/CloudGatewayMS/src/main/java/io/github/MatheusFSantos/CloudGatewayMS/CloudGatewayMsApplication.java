package io.github.MatheusFSantos.CloudGatewayMS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;

@EnableEurekaClient
@EnableDiscoveryClient
@SpringBootApplication
public class CloudGatewayMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CloudGatewayMsApplication.class, args);
	}

	@Bean
	public RouteLocator routes(RouteLocatorBuilder routeLocatorBuilder) {
		return routeLocatorBuilder
				.routes()
					.route(r -> r.path("/api/clients/**").uri("lb://clientms"))
					.route(r -> r.path("/api/cards/**").uri("lb://cardms"))
					.route(r -> r.path("/api/credit-analysis/**").uri("lb://creditanalysisms"))
				.build();
	}

}
