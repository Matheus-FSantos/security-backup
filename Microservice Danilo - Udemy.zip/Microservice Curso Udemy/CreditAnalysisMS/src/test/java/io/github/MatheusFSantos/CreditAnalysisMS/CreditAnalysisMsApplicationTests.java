package io.github.MatheusFSantos.CreditAnalysisMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CreditAnalysisMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
