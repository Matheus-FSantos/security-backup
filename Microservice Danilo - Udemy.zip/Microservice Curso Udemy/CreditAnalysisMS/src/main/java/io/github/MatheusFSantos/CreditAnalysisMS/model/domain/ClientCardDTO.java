package io.github.MatheusFSantos.CreditAnalysisMS.model.domain;

import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.Objects;

@Component
public class ClientCardDTO implements Serializable {

    private String name;

    private String flag;

    private String releasedLimit;

    public ClientCardDTO() { }

    public ClientCardDTO(String name, String flag, String releasedLimit) {
        this.name = name;
        this.flag = flag;
        this.releasedLimit = releasedLimit;
    }

    @Override
    public String toString() {
        return "ClientCardDTO{" +
                "name='" + name + '\'' +
                ", flag='" + flag + '\'' +
                ", releasedLimit='" + releasedLimit + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ClientCardDTO that = (ClientCardDTO) o;
        return Objects.equals(name, that.name) && Objects.equals(flag, that.flag) && Objects.equals(releasedLimit, that.releasedLimit);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, flag, releasedLimit);
    }

    public String getName() {
        return name;
    }

    public void updateName(String name) {
        this.setName(name);
    }

    private void setName(String name) {
        this.name = name;
    }

    public String getFlag() {
        return flag;
    }

    public void updateFlag(String flag) {
        this.setFlag(flag);
    }

    private void setFlag(String flag) {
        this.flag = flag;
    }

    public String getReleasedLimit() {
        return releasedLimit;
    }

    public void updateReleasedLimit(String releasedLimit) {
        this.setReleasedLimit(releasedLimit);
    }

    private void setReleasedLimit(String releasedLimit) {
        this.releasedLimit = releasedLimit;
    }

}
