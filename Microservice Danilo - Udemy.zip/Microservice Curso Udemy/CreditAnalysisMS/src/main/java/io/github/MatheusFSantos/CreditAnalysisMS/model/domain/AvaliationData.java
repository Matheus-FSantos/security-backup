package io.github.MatheusFSantos.CreditAnalysisMS.model.domain;

import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.Objects;

@Component
public class AvaliationData implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private String cpf;
    private Long income;

    public AvaliationData() { }
    
    public AvaliationData(String cpf, Long income) {
        this.cpf = cpf;
        this.income = income;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AvaliationData that = (AvaliationData) o;
        return Objects.equals(cpf, that.cpf) && Objects.equals(income, that.income);
    }

    @Override
    public int hashCode() {
        return Objects.hash(cpf, income);
    }

    @Override
    public String toString() {
        return "AvaliationData{" +
                "cpf='" + cpf + '\'' +
                ", income=" + income +
                '}';
    }

    public String getCpf() {
        return cpf;
    }

    public void updateCpf(String cpf) {
        this.setCpf(cpf);
    }

    private void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public Long getIncome() {
        return income;
    }

    public void updateIncome(Long income) {
        this.setIncome(income);
    }

    private void setIncome(Long income) {
        this.income = income;
    }

}
