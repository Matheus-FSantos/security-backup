package io.github.MatheusFSantos.CreditAnalysisMS.controller.advice;

import io.github.MatheusFSantos.CreditAnalysisMS.model.DTO.CreditAnalysisMSExceptionDTO;
import io.github.MatheusFSantos.CreditAnalysisMS.model.exceptions.CreditAnalysisMSException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class CreditAnalysisAdvice {

    @ExceptionHandler(CreditAnalysisMSException.class)
    public ResponseEntity<?> handleCreditAnalysisMSException(CreditAnalysisMSException creditAnalysisMSException) {
        return ResponseEntity.badRequest().body(
                new CreditAnalysisMSExceptionDTO(creditAnalysisMSException.getExceptionMessages(), creditAnalysisMSException.getExceptionClass(), creditAnalysisMSException.getExceptionDate())
        );
    }

}
