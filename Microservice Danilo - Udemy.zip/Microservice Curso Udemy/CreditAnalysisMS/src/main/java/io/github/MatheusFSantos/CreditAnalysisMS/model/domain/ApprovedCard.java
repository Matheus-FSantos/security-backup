package io.github.MatheusFSantos.CreditAnalysisMS.model.domain;

import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

@Component
public class ApprovedCard implements Serializable {

    private static final long serialVersionUID = 1L;

    private String name;
    
    private String flag;

    private BigDecimal releasedLimit;

    public ApprovedCard() { }

    public ApprovedCard(String name, String flag, BigDecimal releasedLimit) {
        this.name = name;
        this.flag = flag;
        this.releasedLimit = releasedLimit;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ApprovedCard that = (ApprovedCard) o;
        return Objects.equals(name, that.name) && Objects.equals(flag, that.flag) && Objects.equals(releasedLimit, that.releasedLimit);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, flag, releasedLimit);
    }

    @Override
    public String toString() {
        return "ApprovedCard{" +
                "name='" + name + '\'' +
                ", flag='" + flag + '\'' +
                ", releasedLimit=" + releasedLimit +
                '}';
    }

    public String getName() {
        return name;
    }

    public void updateName(String name) {
        this.setName(name);
    }

    private void setName(String name) {
        this.name = name;
    }

    public String getFlag() {
        return flag;
    }

    public void updateFlag(String flag) {
        this.setFlag(flag);
    }

    private void setFlag(String flag) {
        this.flag = flag;
    }

    public BigDecimal getReleasedLimit() {
        return releasedLimit;
    }

    public void updateReleasedLimit(BigDecimal releasedLimit) {
        this.setReleasedLimit(releasedLimit);
    }

    private void setReleasedLimit(BigDecimal releasedLimit) {
        this.releasedLimit = releasedLimit;
    }

}
