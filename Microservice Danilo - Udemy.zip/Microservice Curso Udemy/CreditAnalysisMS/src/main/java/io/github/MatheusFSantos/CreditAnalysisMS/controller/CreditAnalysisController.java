package io.github.MatheusFSantos.CreditAnalysisMS.controller;

import io.github.MatheusFSantos.CreditAnalysisMS.model.domain.*;
import io.github.MatheusFSantos.CreditAnalysisMS.model.exceptions.CreditAnalysisMSException;
import io.github.MatheusFSantos.CreditAnalysisMS.model.service.CreditAnalysisService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/credit-analysis")
public class CreditAnalysisController {

    @Autowired
    private CreditAnalysisService creditAnalysisService;

    @GetMapping(value="/client-situation", params="cpf")
    public ResponseEntity<?> getClientSituation(@RequestParam(name="cpf") String cpf) throws CreditAnalysisMSException {
        ClientSituation clientSituation = creditAnalysisService.getClientSituation(cpf);
        return ResponseEntity.ok().body(clientSituation);
    }

    @PostMapping(value="/client-avaliation")
    public ResponseEntity<?> clientAvaliation(@RequestBody AvaliationData avaliationData) throws CreditAnalysisMSException {
        AvaliationClient avaliationClient = creditAnalysisService.clientAvaliation(avaliationData);
        return ResponseEntity.ok().body(avaliationClient);
    }

    @PostMapping(value="/card-issue")
    public ResponseEntity<?> cardIssueRequest(@RequestBody CardIssueRequest cardIssueRequest) throws CreditAnalysisMSException {
        ProtocolCardIssue protocolCardIssue = this.creditAnalysisService.cardIssueRequest(cardIssueRequest);
        return ResponseEntity.ok().body(protocolCardIssue);
    }

}
