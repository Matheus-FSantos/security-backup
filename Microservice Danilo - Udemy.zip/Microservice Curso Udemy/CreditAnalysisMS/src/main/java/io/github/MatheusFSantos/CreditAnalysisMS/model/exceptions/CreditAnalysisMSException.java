package io.github.MatheusFSantos.CreditAnalysisMS.model.exceptions;

import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Component
public class CreditAnalysisMSException extends Exception {

    private static final long serialVersionUID = 1L;

    private final List<String> exceptionMessages;
    private final String exceptionClass;
    private final LocalDateTime exceptionDate;

    public CreditAnalysisMSException() {
        this.exceptionMessages = new ArrayList<>();
        this.exceptionClass = "CreditAnalysis.class";
        this.exceptionDate = LocalDateTime.now();
    }

    public CreditAnalysisMSException(String exceptionMessages) {
        this.exceptionMessages = Collections.singletonList(exceptionMessages);
        this.exceptionClass = "CreditAnalysis.class";
        this.exceptionDate = LocalDateTime.now();
    }

    public CreditAnalysisMSException(List<String> exceptionMessages) {
        this.exceptionMessages = exceptionMessages;
        this.exceptionClass = "CreditAnalysis.class";
        this.exceptionDate = LocalDateTime.now();
    }

    public List<String> getExceptionMessages() {
        return exceptionMessages;
    }

    public String getExceptionClass() {
        return exceptionClass;
    }

    public LocalDateTime getExceptionDate() {
        return exceptionDate;
    }

}
