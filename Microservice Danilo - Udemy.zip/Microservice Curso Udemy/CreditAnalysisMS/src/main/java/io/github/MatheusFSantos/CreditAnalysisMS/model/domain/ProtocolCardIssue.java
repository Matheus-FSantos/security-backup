package io.github.MatheusFSantos.CreditAnalysisMS.model.domain;

import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.Objects;

@Component
public class ProtocolCardIssue implements Serializable {

    private static final long serialVersionUID = 1L;

    private String protocol;

    public ProtocolCardIssue() { }
    
    public ProtocolCardIssue(String protocol) {
        this.protocol = protocol;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProtocolCardIssue that = (ProtocolCardIssue) o;
        return Objects.equals(protocol, that.protocol);
    }

    @Override
    public int hashCode() {
        return Objects.hash(protocol);
    }

    @Override
    public String toString() {
        return "ProtocolCardIssue{" +
                "protocol='" + protocol + '\'' +
                '}';
    }

    public String getProtocol() {
        return protocol;
    }

    public void updateProtocol(String protocol) {
        this.setProtocol(protocol);
    }

    private void setProtocol(String protocol) {
        this.protocol = protocol;
    }

}
