package io.github.MatheusFSantos.CreditAnalysisMS.model.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

@Component
public class Client implements Serializable {

    private static final long serialVersionUID = 1L;

    private String cpf;

    private String name;

    private String email;

    private Integer age;

    @JsonFormat(pattern="dd/MM/yyyy HH:mm:s")
    private LocalDateTime createdAt;

    @JsonFormat(pattern="dd/MM/yyyy HH:mm:s")
    private LocalDateTime updatedAt;

    public Client() { }

    public Client(String cpf, String name, String email, Integer age, LocalDateTime createdAt, LocalDateTime updatedAt) {
        this.cpf = cpf;
        this.name = name;
        this.email = email;
        this.age = age;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    @Override
    public String toString() {
        return "Client{" +
                "cpf='" + cpf + '\'' +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", age=" + age +
                ", createdAt=" + createdAt +
                ", updatedAt=" + updatedAt +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Client that = (Client) o;
        return Objects.equals(cpf, that.cpf);
    }

    @Override
    public int hashCode() {
        return Objects.hash(cpf);
    }

    public String getCpf() {
        return cpf;
    }

    public void updateCpf(String cpf) {
        this.setCpf(cpf);
    }

    private void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getName() {
        return name;
    }

    public void updateName(String name) {
        this.setName(name);
    }

    private void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void updateEmail(String email) {
        this.setEmail(email);
    }

    private void setEmail(String email) {
        this.email = email;
    }

    public Integer getAge() {
        return age;
    }

    public void updateAge(Integer age) {
        this.setAge(age);
    }

    private void setAge(Integer age) {
        this.age = age;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void updateCreatedAt(LocalDateTime createdAt) {
        this.setCreatedAt(createdAt);
    }

    private void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void updateUpdatedAt(LocalDateTime updatedAt) {
        this.setUpdatedAt(updatedAt);
    }

    private void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
    
}
