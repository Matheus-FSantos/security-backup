package io.github.MatheusFSantos.CreditAnalysisMS.model.domain;

import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

@Component
public class ClientSituation implements Serializable {

    private static final long serialVersionUID = 1L;

    private Client client;

    private List<ClientCardDTO> cards;
    
    public ClientSituation() { }
    
    public ClientSituation(Client client, List<ClientCardDTO> clientCardDTO) {
        this.client = client;
        this.cards = clientCardDTO;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ClientSituation that = (ClientSituation) o;
        return Objects.equals(client, that.client) && Objects.equals(cards, that.cards);
    }

    @Override
    public int hashCode() {
        return Objects.hash(client, cards);
    }

    @Override
    public String toString() {
        return "ClientSituation{" +
                "client=" + client +
                ", cards=" + cards +
                '}';
    }

    public Client getClient() {
        return client;
    }

    public void updateClient(Client client) {
        this.setClient(client);
    }

    private void setClient(Client client) {
        this.client = client;
    }

    public List<ClientCardDTO> getCards() {
        return cards;
    }

    public void updateCards(List<ClientCardDTO> cards) {
        this.setCards(cards);
    }

    private void setCards(List<ClientCardDTO> clientCards) {
        this.cards = clientCards;
    }

}
