package io.github.MatheusFSantos.CreditAnalysisMS.model.feign;

import io.github.MatheusFSantos.CreditAnalysisMS.model.domain.Card;
import io.github.MatheusFSantos.CreditAnalysisMS.model.domain.ClientCardDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(value="cardms", path="/api/cards")
public interface CardFeignClient {

    @GetMapping(params = "cpf")
    public ResponseEntity<List<ClientCardDTO>> findCardsByCpf(@RequestParam String cpf);

    @GetMapping(params = "income")
    public ResponseEntity<List<Card>> findIncomeLessThanEqual(@RequestParam Long income);

}
