package io.github.MatheusFSantos.CreditAnalysisMS.model.feign;

import io.github.MatheusFSantos.CreditAnalysisMS.model.domain.Client;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(value="clientms", path="/api/clients")
public interface ClientFeignClient {

    @GetMapping
    ResponseEntity<List<Client>> findAll();

    @GetMapping(params = "cpf")
    ResponseEntity<Client> findByCPF(@RequestParam String cpf);

}
