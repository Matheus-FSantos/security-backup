package io.github.MatheusFSantos.CreditAnalysisMS.model.infra.mq;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.github.MatheusFSantos.CreditAnalysisMS.model.domain.CardIssueRequest;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class CardIssuePublisher {

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @Autowired
    private Queue queueCardIssue;

    public void sendRequestCard(CardIssueRequest cardIssueRequest) throws JsonProcessingException {
        String JSON = this.convertCardIssueRequestToJson(cardIssueRequest);
        this.rabbitTemplate.convertAndSend(this.queueCardIssue.getName(), JSON);
    }

    private String convertCardIssueRequestToJson(CardIssueRequest cardIssueRequest) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.writeValueAsString(cardIssueRequest);
    }

}
