package io.github.MatheusFSantos.CreditAnalysisMS.model.domain;

import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.List;
import java.util.Objects;

@Component
public class AvaliationClient implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    List<ApprovedCard> approvedCardList;
    
    public AvaliationClient() { }
    
    public AvaliationClient(List<ApprovedCard> approvedCardList) {
        this.approvedCardList = approvedCardList;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AvaliationClient that = (AvaliationClient) o;
        return Objects.equals(approvedCardList, that.approvedCardList);
    }

    @Override
    public int hashCode() {
        return Objects.hash(approvedCardList);
    }

    @Override
    public String toString() {
        return "AvaliationClient{" +
                "approvedCardList=" + approvedCardList +
                '}';
    }

    public List<ApprovedCard> getApprovedCardList() {
        return approvedCardList;
    }

    public void updateApprovedCardList(List<ApprovedCard> approvedCardList) {
        this.setApprovedCardList(approvedCardList);
    }

    private void setApprovedCardList(List<ApprovedCard> approvedCardList) {
        this.approvedCardList = approvedCardList;
    }

}
