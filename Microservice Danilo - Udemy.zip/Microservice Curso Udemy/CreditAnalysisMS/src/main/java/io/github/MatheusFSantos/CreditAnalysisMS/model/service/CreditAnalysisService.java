package io.github.MatheusFSantos.CreditAnalysisMS.model.service;

import feign.FeignException;
import io.github.MatheusFSantos.CreditAnalysisMS.model.domain.*;
import io.github.MatheusFSantos.CreditAnalysisMS.model.exceptions.CreditAnalysisMSException;
import io.github.MatheusFSantos.CreditAnalysisMS.model.feign.CardFeignClient;
import io.github.MatheusFSantos.CreditAnalysisMS.model.feign.ClientFeignClient;
import io.github.MatheusFSantos.CreditAnalysisMS.model.infra.mq.CardIssuePublisher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class CreditAnalysisService {

    @Autowired
    private ClientFeignClient clientFeignClient;

    @Autowired
    private CardFeignClient cardFeignClient;

    @Autowired
    private CardIssuePublisher cardIssuePublisher;

    public ClientSituation getClientSituation(String cpf) throws CreditAnalysisMSException {
        Client client = null;
        List<ClientCardDTO> clientCards = null;

        try {
             client = clientFeignClient.findByCPF(cpf).getBody();
        } catch (FeignException.FeignClientException response) {
            Integer status = response.status();

            if(status.equals(HttpStatus.NOT_FOUND.value()))
                throw new CreditAnalysisMSException("Client not found!");
            else
                throw new CreditAnalysisMSException(response.getMessage());
        }

        try {
            clientCards = cardFeignClient.findCardsByCpf(cpf).getBody();
        } catch (FeignException.FeignClientException response) {
            Integer status = response.status();

            if(status.equals(HttpStatus.NOT_FOUND.value()))
                clientCards = new ArrayList<ClientCardDTO>();
            else
                throw new CreditAnalysisMSException(response.getMessage());
        }

        return new ClientSituation(client, clientCards);
    }

    public AvaliationClient clientAvaliation(AvaliationData avaliationData) throws CreditAnalysisMSException {
        List<Card> cards = null;
        Client client = null;
        
        try {
            cards = cardFeignClient.findIncomeLessThanEqual(avaliationData.getIncome()).getBody();
        } catch (FeignException.FeignClientException response) {
            Integer status = response.status();
            
            if(status.equals(HttpStatus.NOT_FOUND.value()))
                throw new CreditAnalysisMSException("Cards for this income not found!");
            else
                throw new CreditAnalysisMSException(response.getMessage());
        }

        try {
           client = clientFeignClient.findByCPF(avaliationData.getCpf()).getBody();
        } catch (FeignException.FeignClientException response) {
            Integer status = response.status();

            if(status.equals(HttpStatus.NOT_FOUND.value()))
                throw new CreditAnalysisMSException("Client not found!");
            else
                throw new CreditAnalysisMSException(response.getMessage());
        }

        Client finalClient = client;

        if(finalClient != null) {
            List<ApprovedCard> approvedCardList = cards.stream().map(card -> {
                BigDecimal basicLimit = card.getLimit();
                BigDecimal ageBigDecimal = BigDecimal.valueOf(finalClient.getAge());

                BigDecimal factor = ageBigDecimal.divide(BigDecimal.valueOf(10));
                BigDecimal releasedLimit = factor.multiply(basicLimit);

                return new ApprovedCard(card.getName(), card.getFlag(), releasedLimit);
            }).collect(Collectors.toList());

            return new AvaliationClient(approvedCardList);
        }

        throw new CreditAnalysisMSException("No cards approved for this client!");
    }

    public ProtocolCardIssue cardIssueRequest(CardIssueRequest cardIssueRequest) throws CreditAnalysisMSException {
        try {
            this.cardIssuePublisher.sendRequestCard(cardIssueRequest);
            String protocolNumber = UUID.randomUUID().toString();
            return new ProtocolCardIssue(protocolNumber);
        } catch (Exception e) {
            throw new CreditAnalysisMSException(e.getMessage());
        }
    }
}
