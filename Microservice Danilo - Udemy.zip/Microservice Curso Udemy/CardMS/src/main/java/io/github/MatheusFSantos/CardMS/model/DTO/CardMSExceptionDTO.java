package io.github.MatheusFSantos.CardMS.model.DTO;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

@Component
public class CardMSExceptionDTO {

    private List<String> exceptionMessages;
    private String exceptionClass;

    @JsonFormat(pattern = "dd/MM/yyyy HH:mm:s")
    private LocalDateTime exceptionDate;

    public CardMSExceptionDTO() { }

    public CardMSExceptionDTO(List<String> exceptionMessages, String exceptionClass, LocalDateTime exceptionDate) {
        this.exceptionMessages = exceptionMessages;
        this.exceptionClass = exceptionClass;
        this.exceptionDate = exceptionDate;
    }

    public List<String> getExceptionMessages() {
        return exceptionMessages;
    }

    public String getExceptionClass() {
        return exceptionClass;
    }

    public LocalDateTime getExceptionDate() {
        return exceptionDate;
    }

}
