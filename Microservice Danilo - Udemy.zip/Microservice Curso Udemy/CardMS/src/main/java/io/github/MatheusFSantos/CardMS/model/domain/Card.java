package io.github.MatheusFSantos.CardMS.model.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.github.MatheusFSantos.CardMS.model.enumeration.Flag;
import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.UUID;

@Entity
@Component
@Table(name = "card_tb")
public class Card implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(nullable=false)
    private String name;

    @Enumerated(EnumType.STRING)
    private Flag flag;

    @Column(nullable=false)
    private BigDecimal income;

    @Column(nullable=false, name="cardLimit")
    private BigDecimal limit;

    @JsonFormat(pattern="dd/MM/yyyy HH:mm:s")
    private LocalDateTime createdAt;

    @JsonFormat(pattern="dd/MM/yyyy HH:mm:s")
    private LocalDateTime updatedAt;

    public Card() { }

    public Card(Long id, String name, Flag flag, BigDecimal income, BigDecimal limit) {
        this.id = id;
        this.name = name;
        this.flag = flag;
        this.income = income;
        this.limit = limit;
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    @Override
    public String toString() {
        return "Card{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", flag=" + flag +
                ", income=" + income +
                ", limit=" + limit +
                ", createdAt=" + createdAt +
                ", updatedAt=" + updatedAt +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Card card = (Card) o;
        return Objects.equals(id, card.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    public Long getId() {
        return id;
    }

    public void updateId(Long id) {
        this.setId(id);
    }

    private void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void updateName(String name) {
        this.setName(name);
    }

    private void setName(String name) {
        this.name = name;
    }

    public Flag getFlag() {
        return flag;
    }

    public void updateFlag(Flag flag) {
        this.setFlag(flag);
    }

    private void setFlag(Flag flag) {
        this.flag = flag;
    }

    public BigDecimal getIncome() {
        return income;
    }

    public void updateIncome(BigDecimal income) {
        this.setIncome(income);
    }

    private void setIncome(BigDecimal income) {
        this.income = income;
    }

    public BigDecimal getLimit() {
        return limit;
    }

    public void updateLimit(BigDecimal limit) {
        this.setLimit(limit);
    }

    private void setLimit(BigDecimal limit) {
        this.limit = limit;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void updateCreatedAt() {
        this.setCreatedAt(LocalDateTime.now());
    }

    public void updateCreatedAt(LocalDateTime createdAt) {
        this.setCreatedAt(createdAt);
    }

    private void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void updateUpdatedAt() {
        this.setUpdatedAt(LocalDateTime.now());
    }

    private void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

}
