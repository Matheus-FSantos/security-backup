package io.github.MatheusFSantos.CardMS.model.exception;

import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Component
public class CardMSException extends Exception implements Serializable {

    private static final long serialVersionUID = 1L;

    private final List<String> exceptionMessages;
    private final String exceptionClass;
    private final LocalDateTime exceptionDate;

    public CardMSException() {
        this.exceptionMessages = new ArrayList<>();
        this.exceptionClass = "Card.class";
        this.exceptionDate = LocalDateTime.now();
    }

    public CardMSException(String exceptionMessages) {
        this.exceptionMessages = Collections.singletonList(exceptionMessages);
        this.exceptionClass = "Card.class";
        this.exceptionDate = LocalDateTime.now();
    }

    public CardMSException(List<String> exceptionMessages) {
        this.exceptionMessages = exceptionMessages;
        this.exceptionClass = "Card.class";
        this.exceptionDate = LocalDateTime.now();
    }

    public List<String> getExceptionMessages() {
        return exceptionMessages;
    }

    public String getExceptionClass() {
        return exceptionClass;
    }

    public LocalDateTime getExceptionDate() {
        return exceptionDate;
    }

}
