package io.github.MatheusFSantos.CardMS.model.service;

import io.github.MatheusFSantos.CardMS.model.domain.Card;
import io.github.MatheusFSantos.CardMS.model.exception.CardMSException;
import io.github.MatheusFSantos.CardMS.model.repository.CardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;

@Service
public class CardService {

    @Autowired
    private CardRepository cardRepository;

    public List<Card> findAll() {
        return this.cardRepository.findAll();
    }

    public Card findById(Long id) {
        return this.cardRepository.findById(id).orElse(null);
    }

    public List<Card> findByIncomeLessThanEqual(Long income) {
        BigDecimal incomeBigDecimal = BigDecimal.valueOf(income);
        return this.cardRepository.findByIncomeLessThanEqual(incomeBigDecimal);
    }

    @Transactional
    public void save(Card card) {
        card.updateCreatedAt();
        card.updateUpdatedAt();
        this.cardRepository.save(card);
    }

    @Transactional
    public void delete(Long id) throws CardMSException {
        if(this.findById(id) == null)
            throw new CardMSException("Card not found!");

        this.cardRepository.deleteById(id);
    }

}
