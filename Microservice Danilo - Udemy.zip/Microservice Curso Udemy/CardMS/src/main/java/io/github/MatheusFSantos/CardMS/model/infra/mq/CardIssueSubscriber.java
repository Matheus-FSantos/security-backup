package io.github.MatheusFSantos.CardMS.model.infra.mq;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.github.MatheusFSantos.CardMS.model.domain.Card;
import io.github.MatheusFSantos.CardMS.model.domain.CardIssueRequest;
import io.github.MatheusFSantos.CardMS.model.domain.ClientCard;
import io.github.MatheusFSantos.CardMS.model.repository.CardRepository;
import io.github.MatheusFSantos.CardMS.model.repository.ClientCardRepository;
import io.github.MatheusFSantos.CardMS.model.service.CardService;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class CardIssueSubscriber {

    @Autowired
    private CardService cardService;

    @Autowired
    private ClientCardRepository clientCardRepository;

    @RabbitListener(queues="${mq.queues.card-issue}")
    public void getCardRequest(@Payload String payload) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            CardIssueRequest cardIssueRequest = objectMapper.readValue(payload, CardIssueRequest.class);
            Card card = cardService.findById(cardIssueRequest.getCardId());
            ClientCard clientCard = new ClientCard(UUID.randomUUID(), cardIssueRequest.getCpf(), card, cardIssueRequest.getReleasedLimit());
            this.clientCardRepository.save(clientCard);
        } catch (JsonProcessingException exception) {
            System.out.println(exception.getMessage() + ", " + exception.getLocation());
        } catch (Exception e) {
            System.out.println(e.getMessage() + "\n" + e.getCause() + "\n" + e.getLocalizedMessage());
        }
    }

}
