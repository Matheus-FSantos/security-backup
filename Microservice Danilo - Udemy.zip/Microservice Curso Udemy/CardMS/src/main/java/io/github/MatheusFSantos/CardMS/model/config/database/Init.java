package io.github.MatheusFSantos.CardMS.model.config.database;

import io.github.MatheusFSantos.CardMS.model.domain.Card;
import io.github.MatheusFSantos.CardMS.model.enumeration.Flag;
import io.github.MatheusFSantos.CardMS.model.service.CardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@Configuration
public class Init {

    @Bean
    public CommandLineRunner database_config(@Autowired CardService cardService) {
        return args -> {
            List<Card> cards = new ArrayList<Card>(Arrays.asList(
                    new Card(null, "Inter card Platinum", Flag.MASTERCARD, new BigDecimal("3541.00"), new BigDecimal("5250.00")),
                    new Card(null, "Inter card Black", Flag.MASTERCARD, new BigDecimal("7579.00"), new BigDecimal("10550.00")),
                    new Card(null, "Visa card", Flag.VISA, new BigDecimal("1350.00"), new BigDecimal("400.00")),
                    new Card(null, "Visa card", Flag.VISA, new BigDecimal("4350.00"), new BigDecimal("1500.00")),
                    new Card(null, "JCB Black", Flag.JCB, new BigDecimal("20000.00"), new BigDecimal("999999.99"))
            ));

            cards.forEach(card -> {
                cardService.save(card);
            });
        };
    }

}
