package io.github.MatheusFSantos.CardMS.model.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.UUID;

@Entity
@Component
@Table(name="clientCard_tb")
public class ClientCard implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @Column(nullable=false)
    private String cpf;

    @ManyToOne
    @JoinColumn(name="card", nullable=false)
    private Card card;

    @Column(nullable=false)
    private BigDecimal approvedLimit;

    @Column(nullable=false)
    @JsonFormat(pattern="dd/MM/yyyy HH:mm:s")
    private LocalDateTime createdAt;

    @Column(nullable=false)
    @JsonFormat(pattern="dd/MM/yyyy HH:mm:s")
    private LocalDateTime updatedAt;

    public ClientCard() { }

    public ClientCard(UUID id, String cpf, Card card, BigDecimal approvedLimit) {
        this.id = id;
        this.cpf = cpf;
        this.card = card;
        this.approvedLimit = approvedLimit;
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    @Override
    public String toString() {
        return "ClientCard{" +
                "id=" + id +
                ", cpf='" + cpf + '\'' +
                ", card=" + card +
                ", approvedLimit=" + approvedLimit +
                ", createdAt=" + createdAt +
                ", updatedAt=" + updatedAt +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ClientCard that = (ClientCard) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    public UUID getId() {
        return id;
    }

    private void updateId(UUID id) {
        this.setId(id);
    }

    private void setId(UUID id) {
        this.id = id;
    }

    public String getCpf() {
        return cpf;
    }

    public void updateCpf(String cpf) {
        this.setCpf(cpf);
    }

    private void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public Card getCard() {
        return card;
    }

    public void updateCard(Card card) {
        this.setCard(card);
    }

    private void setCard(Card card) {
        this.card = card;
    }

    public BigDecimal getApprovedLimit() {
        return approvedLimit;
    }

    public void updateApprovedLimit(BigDecimal approvedLimit) {
        this.setApprovedLimit(approvedLimit);
    }

    private void setApprovedLimit(BigDecimal approvedLimit) {
        this.approvedLimit = approvedLimit;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void updateCreatedAt() {
        this.setCreatedAt(LocalDateTime.now());
    }

    public void updateCreatedAt(LocalDateTime createdAt) {
        this.setCreatedAt(createdAt);
    }

    private void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void updateUpdatedAt() {
        this.setUpdatedAt(LocalDateTime.now());
    }

    private void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

}
