package io.github.MatheusFSantos.CardMS.model.enumeration;

public enum Flag {

    MASTERCARD,
    VISA,
    ELO,
    AMERICANEXPRESS,
    HIPERCARD,
    DISCOVER,
    AURA,
    DINERSCLUB,
    JCB

}
