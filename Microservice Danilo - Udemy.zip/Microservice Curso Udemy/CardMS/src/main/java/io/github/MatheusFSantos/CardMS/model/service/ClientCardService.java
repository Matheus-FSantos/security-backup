package io.github.MatheusFSantos.CardMS.model.service;

import io.github.MatheusFSantos.CardMS.model.DTO.ClientCardDTO;
import io.github.MatheusFSantos.CardMS.model.domain.ClientCard;
import io.github.MatheusFSantos.CardMS.model.repository.ClientCardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ClientCardService {

    @Autowired
    private ClientCardRepository clientCardRepository;

    public List<ClientCardDTO> findCardsByCpf(String cpf) {
        List<ClientCard> clientCards = this.clientCardRepository.findByCpf(cpf);

        return clientCards.stream().map(ClientCardDTO::fromModel).collect(Collectors.toList());
    }

}
