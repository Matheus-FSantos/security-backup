package io.github.MatheusFSantos.CardMS.model.repository;

import io.github.MatheusFSantos.CardMS.model.domain.ClientCard;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface ClientCardRepository extends JpaRepository<ClientCard, UUID> {

    List<ClientCard> findByCpf(String cpf);

}
