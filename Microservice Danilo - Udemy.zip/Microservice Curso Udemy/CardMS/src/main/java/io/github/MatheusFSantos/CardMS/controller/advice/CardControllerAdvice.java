package io.github.MatheusFSantos.CardMS.controller.advice;

import io.github.MatheusFSantos.CardMS.model.DTO.CardMSExceptionDTO;
import io.github.MatheusFSantos.CardMS.model.exception.CardMSException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class CardControllerAdvice {

    @ExceptionHandler(CardMSException.class)
    public ResponseEntity<?> handleCardMSExceptions(CardMSException cardMSException) {
        return ResponseEntity.badRequest().body(
            new CardMSExceptionDTO(cardMSException.getExceptionMessages(), cardMSException.getExceptionClass(), cardMSException.getExceptionDate())
        );
    }

}
