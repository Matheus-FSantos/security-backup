package io.github.MatheusFSantos.CardMS.model.domain;

import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;
import java.util.UUID;

@Component
public class CardIssueRequest implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long cardId;

    private String cpf;

    private String address;

    private BigDecimal releasedLimit;

    public CardIssueRequest() { }

    public CardIssueRequest(Long cardId, String cpf, String address, BigDecimal releasedLimit) {
        this.cardId = cardId;
        this.cpf = cpf;
        this.address = address;
        this.releasedLimit = releasedLimit;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        CardIssueRequest that = (CardIssueRequest) o;
        return Objects.equals(cardId, that.cardId) && Objects.equals(cpf, that.cpf) && Objects.equals(address, that.address) && Objects.equals(releasedLimit, that.releasedLimit);
    }

    @Override
    public int hashCode() {
        return Objects.hash(cardId, cpf, address, releasedLimit);
    }

    @Override
    public String toString() {
        return "CardIssueRequest{" +
                "cardId=" + cardId +
                ", cpf='" + cpf + '\'' +
                ", address='" + address + '\'' +
                ", releasedLimit=" + releasedLimit +
                '}';
    }

    public Long getCardId() {
        return cardId;
    }

    public void updateCardId(Long cardId) {
        this.setCardId(cardId);
    }

    private void setCardId(Long cardId) {
        this.cardId = cardId;
    }

    public String getCpf() {
        return cpf;
    }

    public void updateCpf(String cpf) {
        this.setCpf(cpf);
    }

    private void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getAddress() {
        return address;
    }

    public void updateAddress(String address) {
        this.setAddress(address);
    }

    private void setAddress(String address) {
        this.address = address;
    }

    public BigDecimal getReleasedLimit() {
        return releasedLimit;
    }

    public void updateReleasedLimit(BigDecimal releasedLimit) {
        this.setReleasedLimit(releasedLimit);
    }

    private void setReleasedLimit(BigDecimal releasedLimit) {
        this.releasedLimit = releasedLimit;
    }

}
