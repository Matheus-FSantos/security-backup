package io.github.MatheusFSantos.CardMS.controller;

import io.github.MatheusFSantos.CardMS.model.DTO.ClientCardDTO;
import io.github.MatheusFSantos.CardMS.model.domain.Card;
import io.github.MatheusFSantos.CardMS.model.exception.CardMSException;
import io.github.MatheusFSantos.CardMS.model.service.CardService;
import io.github.MatheusFSantos.CardMS.model.service.ClientCardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/cards")
public class CardController {

    @Autowired
    private CardService cardService;

    @Autowired
    private ClientCardService clientCardService;

    @GetMapping
    public ResponseEntity<List<Card>> findAll() {
        List<Card> cards = this.cardService.findAll();

        if(!cards.isEmpty())
            return ResponseEntity.ok().body(cards);

        return ResponseEntity.notFound().build();
    }

    @GetMapping(params = "id")
    public ResponseEntity<Card> findById(@RequestParam Long id) {
        System.out.println(id);
        Card card = this.cardService.findById(id);

        if(card != null)
            return ResponseEntity.ok().body(card);

        return ResponseEntity.notFound().build();
    }

    @GetMapping(params = "cpf")
    public ResponseEntity<List<ClientCardDTO>> findCardsByCpf(@RequestParam String cpf) {
        List<ClientCardDTO> clientCards = this.clientCardService.findCardsByCpf(cpf);

        if(!clientCards.isEmpty())
            return ResponseEntity.ok().body(clientCards);

        return ResponseEntity.notFound().build();
    }

    @GetMapping(params = "income")
    public ResponseEntity<List<Card>> findIncomeLessThanEqual(@RequestParam Long income) {
        List<Card> cards = this.cardService.findByIncomeLessThanEqual(income);

        if(!cards.isEmpty())
            return ResponseEntity.ok().body(cards);

        return ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<Void> save(@RequestBody Card card) {
        this.cardService.save(card);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @DeleteMapping(params = "id")
    public ResponseEntity<Void> delete(@RequestParam Long id) throws CardMSException {
        this.cardService.delete(id);
        return ResponseEntity.noContent().build();
    }

}
