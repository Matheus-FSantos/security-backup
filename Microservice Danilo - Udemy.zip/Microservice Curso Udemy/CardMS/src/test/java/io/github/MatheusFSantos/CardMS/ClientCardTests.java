package io.github.MatheusFSantos.CardMS;

import io.github.MatheusFSantos.CardMS.model.service.ClientCardService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientCardTests {

    @Autowired ClientCardService clientCardService;

    @BeforeEach
    void setup() {

    }

    @Test
    void testFindCardsByCpf() {
        System.out.println(this.clientCardService.findCardsByCpf("50202507831"));
    }

}
