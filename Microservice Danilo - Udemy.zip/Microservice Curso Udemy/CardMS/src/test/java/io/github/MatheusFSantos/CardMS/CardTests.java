package io.github.MatheusFSantos.CardMS;

import io.github.MatheusFSantos.CardMS.model.domain.Card;
import io.github.MatheusFSantos.CardMS.model.enumeration.Flag;
import io.github.MatheusFSantos.CardMS.model.exception.CardMSException;
import io.github.MatheusFSantos.CardMS.model.service.CardService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@SpringBootTest
class CardTests {

	List<Card> cards;

	@Autowired CardService cardService;

	@BeforeEach
	void setup() {
		this.cards = new ArrayList<Card>();
		this.cards.addAll(
			Arrays.asList(
				new Card(null, "Inter card Platinum", Flag.MASTERCARD, new BigDecimal("3541.00"), new BigDecimal("5250.00")),
				new Card(null, "Inter card Black", Flag.MASTERCARD, new BigDecimal("7579.00"), new BigDecimal("10550.00")),
				new Card(null, "Visa card", Flag.VISA, new BigDecimal("1350.00"), new BigDecimal("400.00")),
				new Card(null, "Visa card", Flag.VISA, new BigDecimal("4350.00"), new BigDecimal("1500.00")),
				new Card(null, "JCB Black", Flag.JCB, new BigDecimal("20000.00"), new BigDecimal("999999.99"))
			)
		);
	}

	@Test
	void testCardServiceSaveMethod() {
		this.cards.forEach(card -> {
			this.cardService.save(card);
		});
	}

	@Test
	void testCardServiceFindAllMethod() {
		List<Card> cards = this.cardService.findAll();
		System.out.println(cards);
	}

	@Test
	void testCardServiceIncomeLessThanEquals() {
		List<Card> cards = this.cardService.findByIncomeLessThanEqual(10000L);
		System.out.println(cards);
	}

}
